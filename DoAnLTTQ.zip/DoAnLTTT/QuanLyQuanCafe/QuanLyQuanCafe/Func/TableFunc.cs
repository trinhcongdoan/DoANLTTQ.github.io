﻿using QuanLyQuanCafe.ObjectClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe.Func
{
    public class TableFunc
    {
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;
        private static TableFunc instance;

        public static TableFunc Instance
        {
            get { if (instance == null) instance = new TableFunc(); return TableFunc.instance; }
            private set { TableFunc.instance = value; }
        }
        public List<Table> LoadTableList()
        {
            List<Table> tableList = new List<Table>();
            adt = new SqlDataAdapter("SELECT * FROM TABLEFOOD", conn);

            DataTable dt = new DataTable();
            adt.Fill(dt);

            foreach (DataRow item in dt.Rows)
            {
                Table table = new Table(item);
                tableList.Add(table);
            }

            return tableList;
        }
        public List<Table> LoadEmptyTable()
        {
            List<Table> tableList = new List<Table>();
            adt = new SqlDataAdapter($"select * from TableFood where status != 'Có'", conn);

            DataTable dt = new DataTable();
            adt.Fill(dt);

            foreach (DataRow item in dt.Rows)
            {
                Table table = new Table(item);
                tableList.Add(table);
            }

            return tableList;
        }
        public void UpdateTable(int idTable)
        {
            DataTable data = new DataTable();
            string query = $"UPDATE TableFood SET status =N'{"Có"}' WHERE id='{idTable}'";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }
        public void UpdateEmptyTable(int idTable)
        {
            DataTable data = new DataTable();
            string query = $"UPDATE TableFood SET status =N'{"Trống"}' WHERE id='{idTable}'";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }
        public void SwitchTable(int id1, int id2)
        {
            UpdateEmptyTable(id1);
            UpdateTable(id2);
        }
        public bool CheckTableName(string name)
        {
            DataTable data = new DataTable();
            string query = $"SELECT * from TableFood where name =N'{name}'";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
            if(data.Rows.Count > 0)
            {
                return true;
            }
            return false;
        }
        public void InsertTable(string name, string status)
        {
            if (CheckTableName(name))
            {
                MessageBox.Show("Đã tồn tại bàn này!","Thông báo");
                return;
            }
            DataTable data = new DataTable();
            string query = $"INSERT INTO TableFood(name,status) Values (N'{name}',N'{status}')";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }
        public void UpdateTable(int idTable,string name, string status)
        {
            DataTable data = new DataTable();
            string query = $"UPDATE TableFood SET name = N'{name}',status = N'{status}' WHERE id = '{idTable}'";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }

    }
}
