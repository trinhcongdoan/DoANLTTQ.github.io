﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanCafe.Func
{
    public class MenuFunc
    {
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;
        private static MenuFunc instance;

        public static MenuFunc Instance
        {
            get { if (instance == null) instance = new MenuFunc(); return MenuFunc.instance; }
            private set { MenuFunc.instance = value; }
        }
        public List<ObjectClass.Menu> GetListMenuByTable(int id)
        {
            List<ObjectClass.Menu> listMenu = new List<ObjectClass.Menu>();

            string query = "SELECT f.name, bi.count, f.price, f.price*bi.count AS totalPrice FROM dbo.BillInfo AS bi, dbo.Bill AS b, dbo.Food AS f WHERE b.status=0 AND bi.idBill = b.id AND bi.idFood = f.id AND b.idTable = " + id;
            adt = new SqlDataAdapter(query, conn);
            DataTable data = new DataTable();
            adt.Fill(data);

            foreach (DataRow item in data.Rows)
            {
                ObjectClass.Menu menu = new ObjectClass.Menu(item);
                listMenu.Add(menu);
            }

            return listMenu;
        }
    }
}
