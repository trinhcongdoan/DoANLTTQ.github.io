﻿using QuanLyQuanCafe.Func;
using QuanLyQuanCafe.ObjectClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe
{
    public partial class fLogin : Form
    {
        public fLogin()
        {
            InitializeComponent();
        }
        public static string ID_USER = "";
        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            ID_USER = AccountFunc.Instance.getID(txbUserName.Text, txbPassWord.Text);
            if (ID_USER != "")
            {
                Account loginAccount = AccountFunc.Instance.GetAccountByUserName(txbUserName.Text);
                fTableManager f = new fTableManager(loginAccount);
                this.Hide();
                f.ShowDialog();
                this.Show();
                //txbPassWord.Text = "";
            }
            else
            {
                MessageBox.Show("Sai tài khoản hoặc mật khẩu !");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có thật sự muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }
        
    }
}
