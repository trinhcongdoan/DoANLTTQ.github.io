﻿using QuanLyQuanCafe.ObjectClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe.Func
{
    class FoodFunc
    {
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;
        private static FoodFunc instance;

        public static FoodFunc Instance
        {
            get { if (instance == null) instance = new FoodFunc(); return FoodFunc.instance; }
            private set { FoodFunc.instance = value; }
        }

        public List<Food> GetFoodByCategoryID(int id)
        {
            List<Food> list = new List<Food>();

            string query = $"select * from Food where status ='1' and idCategory = " + id;

            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);

            foreach (DataRow item in data.Rows)
            {
                Food food = new Food(item);
                list.Add(food);
            }

            return list;
        }
        public int GetIdFoodByName(string name,string status)
        {
            List<Food> list = new List<Food>();

            string query = $"select * from Food where name =N'{name}' and status='{status}'";

            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);

            if (data.Rows.Count > 0)
            {
                Food food = new Food(data.Rows[0]);

                return food.ID;
            }

            return -1;
        }
        public void InsertFoodByIDCate(int idCategory, string name, float price)
        {
            if (GetIdFoodByName(name,"0") != -1)
            {
                int idFood = GetIdFoodByName(name,"0");
                //MessageBox.Show(idFood.ToString());
                UpdateFoodByIdFood(idFood, name, price, "1");
                return;
            }
            if(GetIdFoodByName(name, "1") != -1)
            {
                MessageBox.Show("Đã có món trong thực đơn!","Thông báo");
                return;
            }
            string query = $"INSERT INTO Food(name, idCategory, price,status) VALUES (N'{name}','{idCategory}','{price}','1')";
            DataSet data = new DataSet();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }

        public void UpdateFoodByIdFood(int idFood, string name, float price, string status)
        {
            if (GetIdFoodByName(name, "1") != -1)
            {
                MessageBox.Show("Đã có món trong thực đơn!", "Thông báo");
                return;
            }
            string query = $"UPDATE Food SET name=N'{name}', price='{price}', status=N'{status}' where id='{idFood}'";
            DataSet data = new DataSet();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }

        public void UpdateFoodByIdCate(int idCate, string status)
        {
            string query = $"UPDATE Food SET status=N'{status}' where idCategory='{idCate}'";
            DataSet data = new DataSet();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }

        public void DeleteFoodByIdFood(int idFood)
        {
            string query = $"UPDATE Food SET status=N'{"0"}' WHERE id='{idFood}'";
            DataSet data = new DataSet();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }
    }
}
