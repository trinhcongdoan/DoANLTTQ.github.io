﻿using QuanLyQuanCafe.ObjectClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe.Func
{
    class BillInfoFunc
    {
        private static BillInfoFunc instance;
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;

        public static BillInfoFunc Instance
        {
            get { if (instance == null) instance = new BillInfoFunc(); return BillInfoFunc.instance; }
            private set { BillInfoFunc.instance = value; }
        }
        public List<BillInfo> GetListBillInfo(int id)
        {
            List<BillInfo> listBillInfo = new List<BillInfo>();

            DataTable data = new DataTable();
            adt = new SqlDataAdapter("SELECT * FROM dbo.BillInfo WHERE idBill = " + id, conn);

            adt.Fill(data);

            foreach (DataRow item in data.Rows)
            {
                BillInfo info = new BillInfo(item);
                listBillInfo.Add(info);
            }

            return listBillInfo;
        }

        public int GetCheckBillInfoByIdBillIdFood(int idBill,int idFood)
        {
            DataTable data = new DataTable();
            adt = new SqlDataAdapter("SELECT * FROM dbo.BillInfo WHERE idBill = " + idBill + " AND idFood = " + idFood, conn);
            adt.Fill(data);
            if (data.Rows.Count > 0)
            {
                return 1;
            }

            return -1;
        }

        public void UpdateBillInfoByIdFoodIdBill(int idBill, int idFood,int count)
        {
            DataTable data = new DataTable();
            string query = $"UPDATE BillInfo SET count =count + {count} WHERE idBill='{idBill}' and idFood ='{idFood}'";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);

        }
        public void InsertBillInfoByIdBill(int idBill, int idFood, int count)
        {
            DataTable data = new DataTable();
            string query = $"INSERT INTO BillInfo( idBill, idFood, count) VALUES ('{idBill}','{idFood}',{count})";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);

        }
    }
}
