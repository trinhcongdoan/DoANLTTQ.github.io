﻿using QuanLyQuanCafe.Func;
using QuanLyQuanCafe.ObjectClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe
{
    public partial class fTableManager : Form
    {
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;

        private Account loginAccount;

        public Account LoginAccount
        {
            get { return loginAccount; }
            set { loginAccount = value; ChangeAccount(loginAccount.Type); }
        }

        void ChangeAccount(int type)
        {
            adminToolStripMenuItem.Enabled = type == 1;
            thôngTinTàiKhoảnToolStripMenuItem.Text += " (" + LoginAccount.DisplayName + ")";
        }

        public fTableManager(Account acc)
        {
            InitializeComponent();
            this.LoginAccount = acc;
            LoadTable();
            LoadCategory();
            LoadEmptyTable();
        }

        void LoadTable()
        {
            flpTable.Controls.Clear();
            List<Table> tableList = TableFunc.Instance.LoadTableList();
            foreach (Table item in tableList)
            {
                Button btn = new Button() { Width = 80, Height = 80 };
                btn.Text = item.Name + Environment.NewLine + item.Status;
                btn.Click += btn_Click;
                btn.Tag = item;
                switch (item.Status)
                {
                    case "Trống":
                        btn.BackColor = Color.Aqua;
                        break;
                    default:
                        btn.BackColor = Color.LightPink;
                        break;
                }

                flpTable.Controls.Add(btn);
            }
        }
        void LoadEmptyTable()
        {
            List<Table> listEmptyTable = TableFunc.Instance.LoadEmptyTable();
            cbSwitchTable.DataSource = listEmptyTable;
            cbSwitchTable.DisplayMember = "Name";
        }
        void LoadCategory()
        {
            List<Category> listCategory = CategoryFunc.Instance.GetListCategory();
            cbCategory.DataSource = listCategory;
            cbCategory.DisplayMember = "Name";
        }
        void LoadFoodListByCategoryID(int id)
        {
            List<Food> listFood = FoodFunc.Instance.GetFoodByCategoryID(id);
            cbFood.DataSource = listFood;
            cbFood.DisplayMember = "Name";
        }

        void btn_Click(object sender, EventArgs e)
        {
            int tableID = ((sender as Button).Tag as Table).ID;
            lsvBill.Tag = (sender as Button).Tag;
            ShowBill(tableID);
        }
        void ShowBill(int id)
        {
            lsvBill.Items.Clear();
            List<ObjectClass.Menu> listBillInfo = MenuFunc.Instance.GetListMenuByTable(id);
            float totalPrice = 0;

            foreach (ObjectClass.Menu item in listBillInfo)
            {
                ListViewItem lsvItem = new ListViewItem(item.FoodName.ToString());
                
                lsvItem.SubItems.Add(item.Count.ToString());
                lsvItem.SubItems.Add(item.Price.ToString());
                lsvItem.SubItems.Add(item.TotalPrice.ToString());
                totalPrice += item.TotalPrice;

                //MessageBox.Show("Đã nhận " + id + " " + item.TotalPrice.ToString());
                lsvBill.Items.Add(lsvItem);
            }
            //MessageBox.Show("Đã nhận " + id + " " +item.TotalPrice.ToString());
            CultureInfo culture = new CultureInfo("vi-VN");
            txbTotalPrice.Text = totalPrice.ToString("c", culture);

        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thôngTinCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAccountProfile f = new fAccountProfile(LoginAccount);
            f.UpdateAccount += f_UpdateAccount;
            f.ShowDialog();
        }
        void f_UpdateAccount(object sender, AccountEvent e)
        {
            thôngTinTàiKhoảnToolStripMenuItem.Text = "Thông tin tài khoản (" + e.Acc.DisplayName + ")";
        }
        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAdmin f = new fAdmin();
            f.ShowDialog();
        }

        private void cbCategory_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            int id = 0;

            ComboBox cb = sender as ComboBox;

            if (cb.SelectedItem == null)
                return;

            Category selected = cb.SelectedItem as Category;
            id = selected.ID;

            LoadFoodListByCategoryID(id);
        }
        private void btnAddFood_Click(object sender, EventArgs e)
        {
            Table table = lsvBill.Tag as Table;
            if (table == null)
            {
                MessageBox.Show("Bạn chưa chọn bàn!", "Thông báo");
                return;
            }
            //MessageBox.Show(table.ID.ToString());
            int idBill = BillFunc.Instance.GetUncheckBillIDByTableID(table.ID);
            int foodID = (cbFood.SelectedItem as Food).ID;
            int count = (int)nmFoodCount.Value;

            

            if (idBill == -1)
            {
                //BillFunc.Instance.InsertBill(table.ID);
                //BillInfoFunc.Instance.InsertBillInfo(BillFunc.Instance.GetMaxIDBill(), foodID, count);
                //MessageBox.Show("Bàn trống");
                TableFunc.Instance.UpdateTable(table.ID);
                BillFunc.Instance.InsertBill(table.ID, 0);
                int idBillCheck = BillFunc.Instance.GetBillID();
                if (idBillCheck == -1)
                {
                    BillInfoFunc.Instance.InsertBillInfoByIdBill(idBill, foodID, count);
                    LoadTable();
                }
                else
                {
                    BillInfoFunc.Instance.InsertBillInfoByIdBill(idBillCheck, foodID, count);
                    LoadTable();
                }
                
            }
            else
            {
                int check = BillInfoFunc.Instance.GetCheckBillInfoByIdBillIdFood(idBill, foodID);
                //DateTime now = DateTime.Now;

                //MessageBox.Show(check.ToString());
                //BillInfoFunc.Instance.InsertBillInfo(idBill, foodID, count);
                if(check == 1)
                {
                    BillInfoFunc.Instance.UpdateBillInfoByIdFoodIdBill(idBill, foodID, count);
                }
                else
                {
                    BillInfoFunc.Instance.InsertBillInfoByIdBill(idBill, foodID, count);
                }


            }

            ShowBill(table.ID);
        }

        private void btnSwitchTable_Click(object sender, EventArgs e)
        {
            Table tb = lsvBill.Tag as Table;
            
            if(tb == null)
            {
                MessageBox.Show("Bạn chưa chọn bàn!", "Thông báo");
                return;
            }
            int id1 = tb.ID;
            int id2 = (cbSwitchTable.SelectedItem as Table).ID;
            int idBill = BillFunc.Instance.GetUncheckBillIDByTableID(id1);
            if (MessageBox.Show(string.Format("Bạn có thật sự muốn chuyển bàn {0} qua bàn {1}", (lsvBill.Tag as Table).Name, (cbSwitchTable.SelectedItem as Table).Name), "Thông báo", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            {
                //MessageBox.Show(idBill.ToString());
                BillFunc.Instance.UpdateBillIdTable(idBill, id2);
                TableFunc.Instance.SwitchTable(id1, id2);
                LoadTable();
            }
        }
        private static CultureInfo ViCultureInfo = System.Globalization.CultureInfo.GetCultureInfo("vi-VN");

        public static string ConvertNumber(string strInput)
        {
            decimal number = decimal.Parse(strInput, ViCultureInfo);
            return number.ToString();
        }
        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            Table tb = lsvBill.Tag as Table;
            if (tb == null)
            {
                MessageBox.Show("Bạn chưa chọn bàn!", "Thông báo");
                return;
            }
            int id1 = tb.ID;
            int idBill = BillFunc.Instance.GetUncheckBillIDByTableID(id1);
            
            string totalStr = txbTotalPrice.Text.Split(',')[0];
            decimal rs;
            bool t = decimal.TryParse(totalStr.Replace(".", ","), out rs);
            double total = (double)rs;
            if (idBill != -1)
            {
                if (MessageBox.Show("Bạn có chắc thanh toán hóa đơn cho bàn " + tb.Name, "Thông báo", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
                {
                    //MessageBox.Show(total.ToString(), "Thông báo");
                    BillFunc.Instance.CheckOut(idBill, total);
                    TableFunc.Instance.UpdateEmptyTable(id1);
                    ShowBill(id1);
                    LoadTable();
                }
            }
            else
            {
                MessageBox.Show("Bàn trống!", "Thông báo");
                return;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadTable();
            LoadCategory();
            LoadEmptyTable();
        }
    }

}
