﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanCafe.Func
{
    class DataProvider
    {
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;
        public DataTable dt;
        private static DataProvider instance;

        public static DataProvider Instance
        {
            get { if (instance == null) instance = new DataProvider(); return DataProvider.instance; }
            private set { DataProvider.instance = value; }
        }
        public void QueryAdapter(string query)
        {
            dt = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(dt);

        }
    }
}
