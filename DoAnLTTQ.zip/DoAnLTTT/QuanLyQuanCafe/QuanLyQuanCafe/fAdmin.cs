﻿using QuanLyQuanCafe.Func;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe
{
    public partial class fAdmin : Form
    {
        public fAdmin()
        {
            InitializeComponent();
        }
        SqlDataAdapter adt = null;
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;

        private void fAdmin_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'qUANLYQUANCAFEDataSet.Bill' table. You can move, or remove it, as needed.
            this.BillTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Bill);
            // TODO: This line of code loads data into the 'qUANLYQUANCAFEDataSet.Account' table. You can move, or remove it, as needed.
            this.accountTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Account);
            // TODO: This line of code loads data into the 'qUANLYQUANCAFEDataSet.TableFood' table. You can move, or remove it, as needed.
            this.tableFoodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.TableFood);
            // TODO: This line of code loads data into the 'qUANLYQUANCAFEDataSet.FoodCategory' table. You can move, or remove it, as needed.
            this.foodCategoryTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.FoodCategory);
            // TODO: This line of code loads data into the 'qUANLYQUANCAFEDataSet.Food' table. You can move, or remove it, as needed.
            this.foodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Food);

            this.reportViewer1.RefreshReport();
        }
        int rowIndex = -1;
        private void dtgvFood_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;
            DataGridViewRow row = dtgvFood.Rows[rowIndex];
            try
            {
                int foodID = (int)row.Cells[0].Value;
                txbFoodID.Text = foodID.ToString();
                txbFoodName.Text = (string)row.Cells[1].Value;
                int idFoodCate = (int)row.Cells[2].Value;
                string nameCate = CategoryFunc.Instance.GetNameCateFoodById(idFoodCate,"1");
                if(CategoryFunc.Instance.GetNameCateFoodById(idFoodCate, "1") == "-1")
                    nameCate = CategoryFunc.Instance.GetNameCateFoodById(idFoodCate, "0");
                cbFoodCategory.SelectedIndex = cbFoodCategory.FindStringExact(nameCate);
                double foodPrice = (double)(row.Cells[3].Value);
                nmFoodPrice.Value = (decimal)foodPrice;
                //MessageBox.Show(nameCate);
            }
            catch (Exception)
            {

                txbFoodID.Text = "";
                txbFoodName.Text = "";
                cbFoodCategory.SelectedIndex = 0;
                nmFoodPrice.Value = 0;
                
            }
            
        }

        private void txbSearchFoodName_TextChanged(object sender, EventArgs e)
        {
            string sql = $"SELECT * FROM Food WHERE name like N'%{txbSearchFoodName.Text}%'";
            adt = new SqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            adt.Fill(ds);
            dtgvFood.DataSource = ds.Tables[0];
        }

        private void dtgvCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;
            DataGridViewRow row = dtgvCategory.Rows[rowIndex];
            try
            {
                int CateID = (int)row.Cells[0].Value;
                txbCategoryID.Text = CateID.ToString();
                textBox2.Text = (string)row.Cells[1].Value;
            }
            catch (Exception)
            {

                txbCategoryID.Text = "";
                textBox2.Text = "";
            }

        }

        private void dtgvTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;
            DataGridViewRow row = dtgvTable.Rows[rowIndex];
            int tableID = (int)row.Cells[0].Value;
            textBox3.Text = tableID.ToString();
            txbTableName.Text = (string)row.Cells[1].Value;
            cbTableStatus.SelectedItem = (string)row.Cells[2].Value;
        }
        
        private void btnAddFood_Click(object sender, EventArgs e)
        {
            
            string name = txbFoodName.Text;
            if (name == "")
            {
                MessageBox.Show("Tên food rỗng");
                return;
            }
            int idCate = (int)cbFoodCategory.SelectedValue;
            double price = (double)nmFoodPrice.Value;
            //MessageBox.Show(name + " " + idCate.ToString() + " " + price.ToString());
            FoodFunc.Instance.InsertFoodByIDCate(idCate, name, (float)price);
            this.foodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Food);

        }

        private void btnDeleteFood_Click(object sender, EventArgs e)
        {
            
            if (txbFoodID.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn hàng nào!");
                return;
            }
            
            //MessageBox.Show(idFood.ToString(), "Thông báo");
            try
            {
                int idFood = int.Parse(txbFoodID.Text);
                FoodFunc.Instance.DeleteFoodByIdFood(idFood);
                //MessageBox.Show(idFood.ToString(),"Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Thông báo");
                return;
            }

            this.foodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Food);
        }

        private void btnEditFood_Click(object sender, EventArgs e)
        {
            if (txbFoodID.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn hàng nào!");
                return;
            }
            int idFood = int.Parse(txbFoodID.Text);
            string name = txbFoodName.Text;
            int idCate = (int)cbFoodCategory.SelectedValue;
            double price = (double)nmFoodPrice.Value;
            //MessageBox.Show(idFood.ToString() + " " + name + " " + idCate.ToString() + " " + price.ToString());
            FoodFunc.Instance.UpdateFoodByIdFood(idFood,name,(float)price,"1");
            this.foodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Food);
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            if(textBox2.Text == "")
            {
                MessageBox.Show("Tên Category trống");
                return;
            }
            string nameCate = textBox2.Text;
            CategoryFunc.Instance.InsertCategoryByName(nameCate);
            this.foodCategoryTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.FoodCategory);
            this.foodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Food);
        }

        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            if (txbCategoryID.Text == "")
            {
                MessageBox.Show("Vui lòng chọn category cần xóa");
                return;
            }
            int idCate = int.Parse(txbCategoryID.Text);
            CategoryFunc.Instance.DeleteCategoryById(idCate);
            this.foodCategoryTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.FoodCategory);
            this.foodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Food);
        }

        private void btnEditCategory_Click(object sender, EventArgs e)
        {
            if(txbCategoryID.Text == "")
            {
                MessageBox.Show("Vui lòng chọn category cần sửa");
                return;
            }
            int idCate = int.Parse(txbCategoryID.Text);
            string nameCate = textBox2.Text;
            CategoryFunc.Instance.UpdateCategoryByIdCate(idCate, nameCate,"1");
            this.foodCategoryTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.FoodCategory);
            this.foodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.Food);

        }

        private void btnAddTable_Click(object sender, EventArgs e)
        {
            if (txbTableName.Text == "")
            {
                MessageBox.Show("Tên bàn trống!", "Thông báo");
                return;
            }
            string name = txbTableName.Text;
            TableFunc.Instance.InsertTable(name, "Trống");
            this.tableFoodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.TableFood);
        }

        private void btnEditTable_Click(object sender, EventArgs e)
        {
            if (textBox3.Text=="")
            {
                MessageBox.Show("Bạn chưa chọn bàn để sửa", "Thông báo");
                return;
            }
            int idTable = int.Parse(textBox3.Text);
            string name = txbTableName.Text;
            string status = cbTableStatus.Text;
            //MessageBox.Show(idTable.ToString() + " " + name + " " + status);
            TableFunc.Instance.UpdateTable(idTable, name, status);
            this.tableFoodTableAdapter.Fill(this.qUANLYQUANCAFEDataSet.TableFood);
        }

        private void btnViewBill_Click(object sender, EventArgs e)
        {
            DateTime checkin = dtpkFromDate.Value;
            DateTime checkout = dtpkToDate.Value;
            //MessageBox.Show(checkin.ToString("yyyy'-'MM'-'dd' 'HH':'mm':'ss") + "-" + checkout.ToString("yyyy'-'MM'-'dd' 'HH':'mm':'ss"));
            string query = $"SELECT * FROM Bill WHERE DateCheckIn>='{checkin.ToString("yyyy'-'MM'-'dd")}' and DateCheckOut<='{checkout.ToString("yyyy'-'MM'-'dd")}'";
            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
            dtgvBill.DataSource = data;
        }

        private void btnDeleteTable_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chức năng xóa bàn sẽ được cập nhật sắp tới! Vui lòng chờ phiên bản cập nhật", "Thông báo");
        }
    }
}
