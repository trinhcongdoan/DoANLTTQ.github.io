﻿using QuanLyQuanCafe.ObjectClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe.Func
{
    class AccountFunc
    {
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;
        private static AccountFunc instance;

        public static AccountFunc Instance
        {
            get { if (instance == null) instance = new AccountFunc(); return AccountFunc.instance; }
            private set { AccountFunc.instance = value; }
        }
        public string getID(string username, string pass)
        {
            string id = "";
            try
            {
                SqlDataAdapter adt = new SqlDataAdapter($"Select * from Account where UserName='{username}' and PassWord='{pass}'", conn);
                DataTable dt = new DataTable();
                adt.Fill(dt);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        id = dr["UserName"].ToString();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi xảy ra khi truy vấn dữ liệu hoặc kết nối với server thất bại !");
            }
            return id;
        }
        public bool UpdateAccount(string userName, string displayName, string pass, string newPass)
        {
            SqlConnection connect = new SqlConnection(conn);
            string query = $"UPDATE Account SET DisplayName=N'{displayName}', PassWord=N'{newPass}' WHERE UserName=N'{userName}' and PassWord=N'{pass}'";
            SqlCommand cmd = new SqlCommand(query,connect);

            try
            {
                connect.Open();
                int rs = cmd.ExecuteNonQuery();
                if (rs > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
            finally
            {
                connect.Close();
            }
            return false;

        }
        public Account GetAccountByUserName(string userName)
        {
            adt = new SqlDataAdapter("Select * from account where userName = '" + userName + "'", conn);
            DataTable data = new DataTable();
            adt.Fill(data);

            foreach (DataRow item in data.Rows)
            {
                return new Account(item);
            }

            return null;
        }

    }
}
