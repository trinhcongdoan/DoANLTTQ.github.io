﻿using QuanLyQuanCafe.ObjectClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe.Func
{
    class BillFunc
    {
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;
        
        private static BillFunc instance;

        public static BillFunc Instance
        {
            get { if (instance == null) instance = new BillFunc(); return BillFunc.instance; }
            private set { BillFunc.instance = value; }
        }
        public int GetUncheckBillIDByTableID(int id)
        {
            DataTable data = new DataTable();
            adt = new SqlDataAdapter("SELECT * FROM dbo.Bill WHERE idTable = " + id + " AND status = 0", conn);
            adt.Fill(data);
            if (data.Rows.Count > 0)
            {
                Bill bill = new Bill(data.Rows[0]);
                
                return bill.ID;
            }

            return -1;
        }
        public int GetBillID()
        {
            DataTable data = new DataTable();
            adt = new SqlDataAdapter("select * from Bill where id not in (select idBill from BillInfo)", conn);
            adt.Fill(data);
            if (data.Rows.Count > 0)
            {
                Bill bill = new Bill(data.Rows[0]);

                return bill.ID;
            }

            return -1;
        }
        public void InsertBill(int idTable,int status)
        {
            DataTable data = new DataTable();
            string query = $"INSERT INTO Bill( idTable, status) VALUES ('{idTable}',{status})";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
            
        }
        public void UpdateBillIdTable(int idBill, int idTable)
        {
            DataTable data = new DataTable();
            string query = $"UPDATE Bill SET idTable ={idTable} WHERE id='{idBill}'";
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);

        }
        public void CheckOut(int id,double total)
        {
            string query = $"UPDATE Bill SET status = 1, DateCheckOut=getdate(), total ={total}  WHERE id = " + id;
            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }
        public void showBillCheckout(DateTime checkin, DateTime checkout)
        {
            string query = $"SELEC * FROM Bill WHERE DateCheckIn>={checkin} and DateCheckOut<={checkout}";
            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }

    }
}
