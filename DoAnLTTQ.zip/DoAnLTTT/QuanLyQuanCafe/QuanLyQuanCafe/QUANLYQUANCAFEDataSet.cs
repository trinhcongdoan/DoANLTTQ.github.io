﻿namespace QuanLyQuanCafe
{


    partial class QUANLYQUANCAFEDataSet
    {
        partial class FoodDataTable
        {
        }
    }
}
