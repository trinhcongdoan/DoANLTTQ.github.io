﻿using QuanLyQuanCafe.ObjectClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCafe.Func
{
    class CategoryFunc
    {
        public string conn = global::QuanLyQuanCafe.Properties.Settings.Default.QUANLYQUANCAFEConnectionString;
        public SqlDataAdapter adt = null;
        private static CategoryFunc instance;

        public static CategoryFunc Instance
        {
            get { if (instance == null) instance = new CategoryFunc(); return CategoryFunc.instance; }
            private set { CategoryFunc.instance = value; }
        }
        public List<Category> GetListCategory()
        {
            List<Category> list = new List<Category>();

            string query = "select * from FoodCategory";
            adt = new SqlDataAdapter(query, conn);

            DataTable data = new DataTable();
            adt.Fill(data);

            foreach (DataRow item in data.Rows)
            {
                Category category = new Category(item);
                list.Add(category);
            }

            return list;
        }

        public int GetIdCateFoodByName(string name, string status)
        {
            string query = $"select * from FoodCategory where name =N'{name}' and status=N'{status}'";

            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);

            if (data.Rows.Count > 0)
            {
                Category cate = new Category(data.Rows[0]);

                return cate.ID;
            }

            return -1;
        }
        public string GetNameCateFoodById(int id, string status)
        {
            string query = $"select * from FoodCategory where id ='{id}' and status ='{status}'";

            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);

            if (data.Rows.Count > 0)
            {
                Category cate = new Category(data.Rows[0]);

                return cate.Name;
            }

            return "-1";
        }

        public void InsertCategoryByName(string name)
        {

            if (GetIdCateFoodByName(name,"0") != -1)
            {
                int idCate = GetIdCateFoodByName(name, "0");
                //MessageBox.Show(idFood.ToString());
                FoodFunc.Instance.UpdateFoodByIdCate(idCate, "1");
                UpdateCategoryByIdCate(idCate, name,"1");
                return;
            }
            if(GetIdCateFoodByName(name, "1") != -1)
            {
                MessageBox.Show("Đã có loại hàng này!", "Thông báo");
                return;
            }
            string query = $"INSERT INTO FoodCategory(name,status) values(N'{name}','1')";
            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }

        public void UpdateCategoryByIdCate(int idCate,string name,string status)
        {
            if (GetIdCateFoodByName(name, "0") != -1)
            {
                int idCateC = GetIdCateFoodByName(name, "0");
                //MessageBox.Show(idFood.ToString());
                FoodFunc.Instance.UpdateFoodByIdCate(idCateC, "1");
                string query = $"UPDATE FoodCategory SET name =N'{name}', status=N'{status}' WHERE id = '{idCate}'";
                DataTable data = new DataTable();
                adt = new SqlDataAdapter(query, conn);
                adt.Fill(data);
                return;
            }
            if (GetIdCateFoodByName(name,"1") != -1)
            {
                MessageBox.Show("Đã có loại hàng này");
                return;
            }
            
        }
        public void DeleteCategoryById(int idCate)
        {
            FoodFunc.Instance.UpdateFoodByIdCate(idCate, "0");
            string query = $"UPDATE FoodCategory SET status ='0' WHERE id = '{idCate}'";
            DataTable data = new DataTable();
            adt = new SqlDataAdapter(query, conn);
            adt.Fill(data);
        }
    }
}
